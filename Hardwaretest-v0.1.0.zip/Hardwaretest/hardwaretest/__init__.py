"""Hardware test GUI package."""
